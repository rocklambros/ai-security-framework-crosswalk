"""Load all JSON data at import time and expose accessor functions.

No runtime file I/O after initial load. All data is cached in module-level variables.
"""

import json
import os

import pandas as pd

_DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
_DERIVED_DIR = os.path.join(_DATA_DIR, "derived")


def _load_json(path):
    with open(path) as f:
        return json.load(f)


# Load everything at import time
# Prefer enriched nodes (with domain assignments) if available
_enriched_path = os.path.join(_DERIVED_DIR, "nodes_enriched.json")
if os.path.exists(_enriched_path):
    _nodes = _load_json(_enriched_path)
else:
    _nodes = _load_json(os.path.join(_DATA_DIR, "nodes.json"))
# Prefer enriched edges (with upstream sources merged) if available
_enriched_edges_path = os.path.join(_DERIVED_DIR, "edges_enriched.json")
if os.path.exists(_enriched_edges_path):
    _edges = _load_json(_enriched_edges_path)
else:
    _edges = _load_json(os.path.join(_DATA_DIR, "edges.json"))
_nodes_df = pd.DataFrame(_nodes)
_edges_df = pd.DataFrame(_edges)
_node_map = {n["node_id"]: n for n in _nodes}

_framework_stats = _load_json(os.path.join(_DERIVED_DIR, "framework_stats.json"))
_coverage_matrix = _load_json(os.path.join(_DERIVED_DIR, "coverage_matrix.json"))
_hierarchy = _load_json(os.path.join(_DERIVED_DIR, "hierarchy.json"))
_transitive_mappings = _load_json(os.path.join(_DERIVED_DIR, "transitive_mappings.json"))
_graph_metrics = _load_json(os.path.join(_DERIVED_DIR, "graph_metrics.json"))
_pairwise_reachability = _load_json(os.path.join(_DERIVED_DIR, "pairwise_reachability.json"))

# Build classifier score lookup from enriched edges and inject into transitive mappings
_classifier_lookup: dict[tuple[str, str], dict] = {}
for _e in _edges:
    _src, _tgt = _e.get("source_node_id"), _e.get("target_node_id")
    if _src and _tgt and _e.get("classifier_tier") is not None:
        _cls = {"classifier_tier": _e["classifier_tier"], "classifier_confidence": _e.get("classifier_confidence")}
        _classifier_lookup[(_src, _tgt)] = _cls
        _classifier_lookup[(_tgt, _src)] = _cls

for _nid, _maps in _transitive_mappings.items():
    for _d in _maps.get("direct", []):
        _key = (_nid, _d["target_node_id"])
        _cls = _classifier_lookup.get(_key)
        if _cls:
            _d.update(_cls)


def get_nodes_df() -> pd.DataFrame:
    return _nodes_df


def get_edges_df() -> pd.DataFrame:
    return _edges_df


def get_node_by_id(node_id: str) -> dict | None:
    return _node_map.get(node_id)


def get_nodes_for_framework(framework: str) -> pd.DataFrame:
    return _nodes_df[_nodes_df["framework"] == framework]


def get_framework_stats() -> dict:
    return _framework_stats


def get_coverage_matrix() -> dict:
    return _coverage_matrix


def get_hierarchy() -> dict:
    return _hierarchy


def get_transitive_mappings() -> dict:
    return _transitive_mappings


def get_graph_metrics() -> dict:
    return _graph_metrics


def get_pairwise_reachability() -> dict:
    return _pairwise_reachability


def get_mappings_for_node(node_id: str) -> dict:
    """Return direct and transitive mappings for a node."""
    return _transitive_mappings.get(node_id, {"direct": [], "transitive": []})
